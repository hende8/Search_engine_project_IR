import nltk
import search_engine_best

nltk.download('stopwords')
nltk.download('punkt')

search_engine_best.main()