import search_engine_best

if __name__ == '__main__':
    search_engine_best.main()
